package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> listDataHeader;
    HashMap<String, List<String>> listDataChild;
    String gPos, cPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get the listview
        expListView = (ExpandableListView) findViewById(R.id.LearnerList);

        // preparing list data
        prepareListData();

        listAdapter = new ExpandableListAdapter(this, listDataHeader, listDataChild);

        // setting list adapter
        expListView.setAdapter(listAdapter);

        expListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v,
                                        int groupPosition, long id) {
                // Toast.makeText(getApplicationContext(),
                // "Group Clicked " + listDataHeader.get(groupPosition),
                // Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        // Listview Group expanded listener
        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                Toast.makeText(getApplicationContext(),
                        listDataHeader.get(groupPosition) + " Expanded",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Listview Group collasped listener
        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
                Toast.makeText(getApplicationContext(),
                        listDataHeader.get(groupPosition) + " Collapsed",
                        Toast.LENGTH_SHORT).show();

            }
        });

        // Listview on child click listener
        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                // TODO Auto-generated method stub
                Toast.makeText(
                        getApplicationContext(),
                        listDataHeader.get(groupPosition)
                                + " : "
                                + listDataChild.get(
                                listDataHeader.get(groupPosition)).get(
                                childPosition), Toast.LENGTH_SHORT)
                        .show();
                cPos = listDataChild.get(
                        listDataHeader.get(groupPosition)).get(
                        childPosition);
                gPos = listDataHeader.get(groupPosition);
                Toast.makeText(getApplicationContext(),gPos+" : "+cPos,Toast.LENGTH_LONG);

                nextOne();
                return false;

            }
        });
    }
    private void nextOne(){

        if(cPos.equals("Create Group") && gPos.equals("Group")){
            Intent myIntent = new Intent(this, CreateGroup.class);
            startActivity(myIntent);
        }else if(cPos.equals("Join Group") && gPos.equals("Group")){
            Intent myIntent = new Intent(this, JoinGroup.class);
            startActivity(myIntent);
        }else if(cPos.equals("List Group") && gPos.equals("Group")){
            Intent myIntent = new Intent(this, ListGroup.class);
            startActivity(myIntent);
        }else if(cPos.equals("Join Assignment") && gPos.equals("Assignment")){
            Intent myIntent = new Intent(this,JoinAssignment.class);
            startActivity(myIntent);
        }else if(cPos.equals("List Assignments") && gPos.equals("Assignment")){
            Intent myIntent = new Intent(this, ListAssignment.class);
            startActivity(myIntent);
        }
    }
    /*
     * Preparing the list data
     */
    private void prepareListData() {
        listDataHeader = new ArrayList<String>();
        listDataChild = new HashMap<String, List<String>>();

        // Adding child data
        listDataHeader.add("Group");
        listDataHeader.add("Assignment");

        // Adding child data
        List<String> lGroup= new ArrayList<String>();
        lGroup.add("Create Group");
        lGroup.add("Join Group");
        lGroup.add("List Group"); //leave group
       //lGroup.add("Group Info"); //maybe join with list group

        List<String> lAssignment = new ArrayList<String>();
        lAssignment.add("Join Assignment");
        lAssignment.add("List Assignments"); // assignment info


        listDataChild.put(listDataHeader.get(0), lGroup); // Header, Child data
        listDataChild.put(listDataHeader.get(1),lAssignment);
    }
}
